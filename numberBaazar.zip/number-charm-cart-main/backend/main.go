
package main

import (
	"database/sql"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
	"github.com/joho/godotenv"
)

type PhoneNumber struct {
	ID               int     `json:"id"`
	MobileNumber     string  `json:"mobile_number"`
	Price            float64 `json:"price"`
	DiscountedPrice  float64 `json:"discounted_price"`
}

type Server struct {
	db *sql.DB
}

func main() {
	// Load environment variables
	err := godotenv.Load()
	if err != nil {
		log.Println("No .env file found, using system environment variables")
	}

	// Initialize database connection
	db, err := initDB()
	if err != nil {
		log.Fatal("Failed to connect to database:", err)
	}
	defer db.Close()

	server := &Server{db: db}

	// Initialize Gin router
	router := gin.Default()

	// Add CORS middleware
	router.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type, Authorization")
		
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		
		c.Next()
	})

	// Routes
	router.GET("/phone-numbers", server.getAllPhoneNumbers)
	router.GET("/phone-numbers/:id", server.getPhoneNumberByID)

	// Health check endpoint
	router.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "healthy"})
	})

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("Server starting on port %s", port)
	log.Fatal(router.Run(":" + port))
}

func initDB() (*sql.DB, error) {
	dbUser := getEnvOrDefault("DB_USER", "root")
	dbPassword := getEnvOrDefault("DB_PASSWORD", "")
	dbHost := getEnvOrDefault("DB_HOST", "localhost")
	dbPort := getEnvOrDefault("DB_PORT", "3306")
	dbName := getEnvOrDefault("DB_NAME", "vip_numbers")

	dsn := dbUser + ":" + dbPassword + "@tcp(" + dbHost + ":" + dbPort + ")/" + dbName + "?parseTime=true"
	
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		return nil, err
	}

	// Test the connection
	err = db.Ping()
	if err != nil {
		return nil, err
	}

	// Set connection pool settings
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(25)

	log.Println("Successfully connected to database")
	return db, nil
}

func (s *Server) getAllPhoneNumbers(c *gin.Context) {
	query := "SELECT id, mobile_number, price, discounted_price FROM phone_numbers"
	
	rows, err := s.db.Query(query)
	if err != nil {
		log.Printf("Database query error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to fetch phone numbers",
		})
		return
	}
	defer rows.Close()

	var phoneNumbers []PhoneNumber
	
	for rows.Next() {
		var pn PhoneNumber
		err := rows.Scan(&pn.ID, &pn.MobileNumber, &pn.Price, &pn.DiscountedPrice)
		if err != nil {
			log.Printf("Row scan error: %v", err)
			continue
		}
		phoneNumbers = append(phoneNumbers, pn)
	}

	if err = rows.Err(); err != nil {
		log.Printf("Rows iteration error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Error processing results",
		})
		return
	}

	// Return empty array if no records found
	if phoneNumbers == nil {
		phoneNumbers = []PhoneNumber{}
	}

	c.JSON(http.StatusOK, phoneNumbers)
}

func (s *Server) getPhoneNumberByID(c *gin.Context) {
	idParam := c.Param("id")
	id, err := strconv.Atoi(idParam)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Invalid ID format",
		})
		return
	}

	query := "SELECT id, mobile_number, price, discounted_price FROM phone_numbers WHERE id = ?"
	
	var pn PhoneNumber
	err = s.db.QueryRow(query, id).Scan(&pn.ID, &pn.MobileNumber, &pn.Price, &pn.DiscountedPrice)
	
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{
				"error": "Phone number not found",
			})
			return
		}
		log.Printf("Database query error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to fetch phone number",
		})
		return
	}

	c.JSON(http.StatusOK, pn)
}

func getEnvOrDefault(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}
