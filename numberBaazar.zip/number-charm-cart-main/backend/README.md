
# VIP Numbers Backend API

A Go backend server that serves VIP phone number data from a MySQL database.

## Setup

1. **Install Go** (version 1.21 or higher)

2. **Install dependencies:**
   ```bash
   cd backend
   go mod tidy
   ```

3. **Setup MySQL database:**
   ```sql
   CREATE DATABASE vip_numbers;
   USE vip_numbers;
   
   CREATE TABLE phone_numbers (
     id INT PRIMARY KEY AUTO_INCREMENT,
     mobile_number VARCHAR(20) NOT NULL,
     price DECIMAL(10,2) NOT NULL,
     discounted_price DECIMAL(10,2) NOT NULL
   );
   
   -- Insert sample data
   INSERT INTO phone_numbers (mobile_number, price, discounted_price) VALUES
   ('9999988888', 5000.00, 4500.00),
   ('9876543210', 8000.00, 7600.00),
   ('9999999999', 15000.00, 13500.00);
   ```

4. **Configure environment variables:**
   ```bash
   cp .env.example .env
   # Edit .env with your database credentials
   ```

5. **Run the server:**
   ```bash
   go run main.go
   ```

## API Endpoints

### GET /phone-numbers
Returns all phone number records.

**Response:**
```json
[
  {
    "id": 1,
    "mobile_number": "9999988888",
    "price": 5000.00,
    "discounted_price": 4500.00
  }
]
```

### GET /phone-numbers/:id
Returns a specific phone number by ID.

**Response:**
```json
{
  "id": 1,
  "mobile_number": "9999988888",
  "price": 5000.00,
  "discounted_price": 4500.00
}
```

### GET /health
Health check endpoint.

## Environment Variables

- `DB_USER`: MySQL username (default: root)
- `DB_PASSWORD`: MySQL password
- `DB_HOST`: MySQL host (default: localhost)
- `DB_PORT`: MySQL port (default: 3306)
- `DB_NAME`: Database name (default: vip_numbers)
- `PORT`: Server port (default: 8080)

## Features

- RESTful API design
- CORS support for frontend integration
- Connection pooling
- Error handling with appropriate HTTP status codes
- Environment-based configuration
- Health check endpoint
